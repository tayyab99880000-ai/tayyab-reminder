# Generates launcher icons into native/res (run once; PNGs are committed).
from PIL import Image, ImageDraw
import os

BLUE = (74, 144, 226, 255)
WHITE = (255, 255, 255, 255)
SS = 4  # supersampling

def draw_bell(d, cx, cy, h, color):
    """Bell centred at (cx,cy), total height h."""
    w = h * 0.86
    top = cy - h / 2
    # knob
    r = h * 0.045
    d.ellipse([cx - r, top, cx + r, top + 2 * r], fill=color)
    # dome
    dome_top = top + h * 0.07
    dome_h = h * 0.52
    d.ellipse([cx - w * 0.36, dome_top, cx + w * 0.36, dome_top + dome_h], fill=color)
    # flared body
    body_top = dome_top + dome_h * 0.5
    body_bot = top + h * 0.80
    d.polygon([(cx - w * 0.36, body_top), (cx + w * 0.36, body_top),
               (cx + w * 0.50, body_bot), (cx - w * 0.50, body_bot)], fill=color)
    # rim
    d.rounded_rectangle([cx - w * 0.52, body_bot - h * 0.03, cx + w * 0.52, body_bot + h * 0.06],
                        radius=h * 0.04, fill=color)
    # clapper
    cr = h * 0.075
    cyb = top + h * 0.90
    d.ellipse([cx - cr, cyb - cr * 0.4, cx + cr, cyb + cr * 1.6], fill=color)

def make(size, kind):
    S = size * SS
    img = Image.new('RGBA', (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    if kind == 'foreground':
        # adaptive icon: keep bell inside central 61% (safe zone)
        draw_bell(d, S / 2, S / 2, S * 0.40, WHITE)
    elif kind == 'round':
        d.ellipse([0, 0, S - 1, S - 1], fill=BLUE)
        draw_bell(d, S / 2, S / 2, S * 0.52, WHITE)
    else:
        d.rounded_rectangle([0, 0, S - 1, S - 1], radius=S * 0.22, fill=BLUE)
        draw_bell(d, S / 2, S / 2, S * 0.54, WHITE)
    return img.resize((size, size), Image.LANCZOS)

dens = {'mdpi': (48, 108), 'hdpi': (72, 162), 'xhdpi': (96, 216),
        'xxhdpi': (144, 324), 'xxxhdpi': (192, 432)}
out = os.path.join(os.path.dirname(__file__), '..', 'native', 'res')
for name, (legacy, fg) in dens.items():
    p = os.path.join(out, 'mipmap-' + name)
    os.makedirs(p, exist_ok=True)
    make(legacy, 'legacy').save(os.path.join(p, 'ic_launcher.png'))
    make(legacy, 'round').save(os.path.join(p, 'ic_launcher_round.png'))
    make(fg, 'foreground').save(os.path.join(p, 'ic_launcher_foreground.png'))
make(1024, 'legacy').save(os.path.join(out, '..', 'icon-preview.png'))
print('icons done')
