// Run after `npx cap add android`.
// Copies our native Java code + patches AndroidManifest, theme and icon colors.
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const app = path.join(root, 'android', 'app', 'src', 'main');
const javaDir = path.join(app, 'java', 'com', 'tayyab', 'reminder');

// 1. Java sources
fs.mkdirSync(javaDir, { recursive: true });
const srcDir = path.join(root, 'native', 'java');
for (const f of fs.readdirSync(srcDir)) {
  fs.copyFileSync(path.join(srcDir, f), path.join(javaDir, f));
}
console.log('Java files copied:', fs.readdirSync(srcDir).join(', '));

// 2. Manifest
const manifestPath = path.join(app, 'AndroidManifest.xml');
let m = fs.readFileSync(manifestPath, 'utf8');

const perms = `
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.USE_EXACT_ALARM" />
    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />
    <uses-permission android:name="android.permission.USE_FULL_SCREEN_INTENT" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-permission android:name="android.permission.VIBRATE" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" />
    <uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />
`;

const comps = `
        <activity
            android:name=".AlarmActivity"
            android:exported="false"
            android:launchMode="singleInstance"
            android:taskAffinity=""
            android:excludeFromRecents="true"
            android:showWhenLocked="true"
            android:turnScreenOn="true"
            android:theme="@android:style/Theme.DeviceDefault.NoActionBar.Fullscreen" />

        <service
            android:name=".AlarmService"
            android:exported="false"
            android:foregroundServiceType="mediaPlayback" />

        <receiver android:name=".AlarmReceiver" android:exported="false" />

        <receiver android:name=".BootReceiver" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED" />
                <action android:name="android.intent.action.QUICKBOOT_POWERON" />
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON" />
            </intent-filter>
        </receiver>
`;

if (!m.includes('AlarmActivity')) {
  if (!m.includes('</application>')) throw new Error('Manifest: </application> not found');
  m = m.replace('</application>', comps + '    </application>');
  // permissions go right after <manifest ...>
  m = m.replace(/(<manifest[^>]*>)/, '$1\n' + perms);
  fs.writeFileSync(manifestPath, m);
  console.log('Manifest patched');
}

// 3. Theme: white status/navigation bar, plain white launch background
const stylesPath = path.join(app, 'res', 'values', 'styles.xml');
if (fs.existsSync(stylesPath)) {
  let st = fs.readFileSync(stylesPath, 'utf8');
  st = st.replace(/<item name="android:background">@drawable\/splash<\/item>/g,
                  '<item name="android:background">#FFFFFF</item>');
  if (!st.includes('android:statusBarColor')) {
    st = st.replace(/(<style name="AppTheme.NoActionBar"[^>]*>)/,
      '$1\n        <item name="android:statusBarColor">#FFFFFF</item>\n' +
      '        <item name="android:navigationBarColor">#FFFFFF</item>\n' +
      '        <item name="android:windowLightStatusBar">true</item>');
  }
  fs.writeFileSync(stylesPath, st);
  console.log('Theme patched');
}

// 4. Adaptive icon background colour
const bgPath = path.join(app, 'res', 'values', 'ic_launcher_background.xml');
if (fs.existsSync(bgPath)) {
  fs.writeFileSync(bgPath,
    '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#4A90E2</color>\n</resources>\n');
}

// 5. Launcher icons (pre-generated PNGs in native/res)
function copyDir(from, to) {
  for (const e of fs.readdirSync(from, { withFileTypes: true })) {
    const a = path.join(from, e.name), b = path.join(to, e.name);
    if (e.isDirectory()) { fs.mkdirSync(b, { recursive: true }); copyDir(a, b); }
    else fs.copyFileSync(a, b);
  }
}
copyDir(path.join(root, 'native', 'res'), path.join(app, 'res'));
console.log('Icons copied');
