// Builds the web part of the app into ./www (offline: no CDN needed)
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const root = path.join(__dirname, '..');
const www = path.join(root, 'www');

fs.rmSync(www, { recursive: true, force: true });
fs.mkdirSync(path.join(www, 'fonts'), { recursive: true });
fs.mkdirSync(path.join(www, 'phosphor'), { recursive: true });

// 1. Tailwind CSS
execSync('npx tailwindcss -c tailwind.config.js -i src/input.css -o www/app.css --minify', { cwd: root, stdio: 'inherit' });

// 2. HTML + JS
fs.copyFileSync(path.join(root, 'src', 'index.html'), path.join(www, 'index.html'));
fs.copyFileSync(path.join(root, 'src', 'app.js'), path.join(www, 'app.js'));

// 3. Icons (Phosphor Bold)
const ph = path.join(root, 'node_modules', '@phosphor-icons', 'web', 'src', 'bold');
for (const f of fs.readdirSync(ph)) {
  if (f === 'style.css' || f.endsWith('.woff2') || f.endsWith('.woff')) {
    fs.copyFileSync(path.join(ph, f), path.join(www, 'phosphor', f));
  }
}

// 4. Font (Inter)
const inter = path.join(root, 'node_modules', '@fontsource-variable', 'inter', 'files', 'inter-latin-wght-normal.woff2');
fs.copyFileSync(inter, path.join(www, 'fonts', 'inter-latin-wght-normal.woff2'));

console.log('Web build done -> www/');
