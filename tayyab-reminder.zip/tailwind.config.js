module.exports = {
  content: ['./src/**/*.html', './src/**/*.js'],
  theme: {
    extend: {
      colors: {
        brand: {
          blue: '#4A90E2',
          blueHover: '#357ABD',
          blueLight: '#EBF3FA',
          navy: '#202A44',
          navyLight: '#324066',
          bgLight: '#F5F7FA',
          success: '#2ECC71',
          danger: '#E74C3C',
          cardBg: '#FFFFFF'
        }
      },
      fontFamily: { sans: ['Inter', 'sans-serif'] },
      boxShadow: {
        soft: '0 10px 25px -5px rgba(32, 42, 68, 0.05), 0 8px 10px -6px rgba(32, 42, 68, 0.03)',
        float: '0 12px 20px -4px rgba(74, 144, 226, 0.4)'
      }
    }
  }
};
