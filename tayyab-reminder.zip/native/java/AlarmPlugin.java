package com.tayyab.reminder;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import org.json.JSONArray;
import org.json.JSONObject;

/** JavaScript <-> native bridge for alarms and permission screens. */
@CapacitorPlugin(
        name = "TayyabAlarm",
        permissions = {
                @Permission(strings = {"android.permission.POST_NOTIFICATIONS"}, alias = "notifications")
        }
)
public class AlarmPlugin extends Plugin {

    @PluginMethod
    public void syncAll(PluginCall call) {
        try {
            JSArray arr = call.getArray("alarms");
            JSONArray fresh = new JSONArray();
            if (arr != null) {
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    JSONObject n = new JSONObject();
                    n.put("id", o.getString("id"));
                    n.put("title", o.optString("title", "Reminder"));
                    n.put("body", o.optString("body", ""));
                    n.put("time", o.getLong("timestamp"));
                    fresh.put(n);
                }
            }
            AlarmScheduler.syncAll(getContext(), fresh);
            call.resolve();
        } catch (Exception e) {
            call.reject("syncAll failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void testAlarm(PluginCall call) {
        long t = System.currentTimeMillis() + 10000L;
        AlarmScheduler.add(getContext(), "snooze:test", "Test Alarm", "Your alarm is working!", t);
        call.resolve();
    }

    @PluginMethod
    public void checkStatus(PluginCall call) {
        Context c = getContext();
        JSObject r = new JSObject();

        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        boolean notif = nm != null && nm.areNotificationsEnabled();

        boolean exact = true;
        if (Build.VERSION.SDK_INT >= 31) {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            exact = am != null && am.canScheduleExactAlarms();
        }

        boolean fullScreen = true;
        if (Build.VERSION.SDK_INT >= 34 && nm != null) {
            fullScreen = nm.canUseFullScreenIntent();
        }

        boolean battery = true;
        if (Build.VERSION.SDK_INT >= 23) {
            PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
            battery = pm != null && pm.isIgnoringBatteryOptimizations(c.getPackageName());
        }

        r.put("notifications", notif);
        r.put("exact", exact);
        r.put("fullScreen", fullScreen);
        r.put("battery", battery);
        call.resolve(r);
    }

    @PluginMethod
    public void requestNotifications(PluginCall call) {
        if (Build.VERSION.SDK_INT >= 33 && getPermissionState("notifications") != PermissionState.GRANTED) {
            requestPermissionForAlias("notifications", call, "notifCallback");
        } else {
            call.resolve();
        }
    }

    @PermissionCallback
    private void notifCallback(PluginCall call) {
        call.resolve();
    }

    @PluginMethod
    public void openSetting(PluginCall call) {
        String type = call.getString("type", "app");
        Context c = getContext();
        String pkg = c.getPackageName();
        Uri pkgUri = Uri.parse("package:" + pkg);
        try {
            Intent i = null;
            if ("exact".equals(type)) {
                if (Build.VERSION.SDK_INT >= 31) {
                    i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkgUri);
                }
            } else if ("fullscreen".equals(type)) {
                if (Build.VERSION.SDK_INT >= 34) {
                    i = new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, pkgUri);
                }
            } else if ("notifications".equals(type)) {
                i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                i.putExtra(Settings.EXTRA_APP_PACKAGE, pkg);
            } else if ("battery".equals(type)) {
                i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkgUri);
            } else if ("autostart".equals(type)) {
                if (openAutoStart()) {
                    call.resolve();
                    return;
                }
            }
            if (i == null) {
                i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri);
            }
            startSafe(i);
            call.resolve();
        } catch (Exception e) {
            try {
                startSafe(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri));
                call.resolve();
            } catch (Exception e2) {
                call.reject("Could not open settings");
            }
        }
    }

    private void startSafe(Intent i) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(i);
    }

    /** Oppo / Realme / OnePlus (ColorOS) auto-start screens. Falls back to app details. */
    private boolean openAutoStart() {
        String[][] targets = new String[][]{
                {"com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"},
                {"com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity"},
                {"com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity"},
                {"com.coloros.oppoguardelf", "com.coloros.powermanager.fuelgaue.PowerUsageModelActivity"},
                {"com.oplus.battery", "com.oplus.powermanager.fuelgaue.PowerUsageModelActivity"}
        };
        for (String[] t : targets) {
            try {
                Intent i = new Intent();
                i.setComponent(new ComponentName(t[0], t[1]));
                startSafe(i);
                return true;
            } catch (Exception ignored) {
            }
        }
        return false;
    }
}
