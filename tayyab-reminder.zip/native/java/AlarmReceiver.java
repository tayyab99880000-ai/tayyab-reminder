package com.tayyab.reminder;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.core.content.ContextCompat;

/** Fires when an alarm time is reached. Starts the ringing service. */
public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        String id = intent.getStringExtra("id");
        if (id == null) id = "alarm";
        String title = intent.getStringExtra("title");
        String body = intent.getStringExtra("body");
        long time = intent.getLongExtra("time", System.currentTimeMillis());

        AlarmScheduler.removeEntry(context, id);

        Intent s = new Intent(context, AlarmService.class);
        s.setAction(AlarmService.ACTION_START);
        s.putExtra("id", id);
        s.putExtra("title", title == null ? "Reminder" : title);
        s.putExtra("body", body == null ? "" : body);
        s.putExtra("time", time);
        ContextCompat.startForegroundService(context, s);
    }
}
