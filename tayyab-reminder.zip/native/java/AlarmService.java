package com.tayyab.reminder;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;

import androidx.core.app.NotificationCompat;

/**
 * Foreground service that rings like an alarm clock:
 * loud looping sound + vibration + full-screen alarm screen.
 */
public class AlarmService extends Service {
    public static final String ACTION_START = "com.tayyab.reminder.START";
    public static final String ACTION_DISMISS = "com.tayyab.reminder.DISMISS";
    public static final String ACTION_SNOOZE = "com.tayyab.reminder.SNOOZE";
    public static final String ACTION_STOPPED = "com.tayyab.reminder.ALARM_STOPPED";

    static final String CHANNEL_ID = "tayyab_alarm_channel_v1";
    static final int NOTIF_ID = 7001;
    static final long SNOOZE_MS = 5L * 60L * 1000L;
    static final long MAX_RING_MS = 2L * 60L * 1000L;

    private MediaPlayer player;
    private Vibrator vibrator;
    private PowerManager.WakeLock wakeLock;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private String curId = "alarm";
    private String curTitle = "Reminder";
    private String curBody = "";
    private long curTime = 0L;

    private final Runnable autoStop = new Runnable() {
        @Override
        public void run() {
            stopEverything();
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();

        if (ACTION_DISMISS.equals(action)) {
            stopEverything();
            return START_NOT_STICKY;
        }

        if (ACTION_SNOOZE.equals(action)) {
            String id = intent.getStringExtra("id");
            if (id == null) id = curId;
            String title = intent.getStringExtra("title");
            if (title == null) title = curTitle;
            String body = intent.getStringExtra("body");
            if (body == null) body = curBody;
            String sid = id.startsWith("snooze:") ? id : "snooze:" + id;
            AlarmScheduler.add(this, sid, title, body, System.currentTimeMillis() + SNOOZE_MS);
            stopEverything();
            return START_NOT_STICKY;
        }

        if (intent == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        // ACTION_START
        String id = intent.getStringExtra("id");
        if (id != null) curId = id;
        String title = intent.getStringExtra("title");
        if (title != null) curTitle = title;
        String body = intent.getStringExtra("body");
        if (body != null) curBody = body;
        curTime = intent.getLongExtra("time", System.currentTimeMillis());

        createChannel();
        Notification n = buildNotification();
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            } else {
                startForeground(NOTIF_ID, n);
            }
        } catch (Exception e) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NOTIF_ID, n);
        }

        startRinging();

        handler.removeCallbacks(autoStop);
        handler.postDelayed(autoStop, MAX_RING_MS);

        // Try to open the alarm screen directly (works when the phone allows it).
        try {
            Intent a = alarmActivityIntent();
            a.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(a);
        } catch (Exception ignored) {
        }

        return START_NOT_STICKY;
    }

    private Intent alarmActivityIntent() {
        Intent i = new Intent(this, AlarmActivity.class);
        i.putExtra("id", curId);
        i.putExtra("title", curTitle);
        i.putExtra("body", curBody);
        i.putExtra("time", curTime);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_USER_ACTION);
        return i;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Task alarms", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Alarm-style reminders for your tasks");
            ch.setSound(null, null);
            ch.enableVibration(false);
            ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            nm.createNotificationChannel(ch);
        }
    }

    private Notification buildNotification() {
        int pf = AlarmScheduler.flags();

        PendingIntent fullPi = PendingIntent.getActivity(this, 11, alarmActivityIntent(), pf);

        Intent snooze = new Intent(this, AlarmService.class);
        snooze.setAction(ACTION_SNOOZE);
        snooze.putExtra("id", curId);
        snooze.putExtra("title", curTitle);
        snooze.putExtra("body", curBody);
        PendingIntent snoozePi = PendingIntent.getService(this, 12, snooze, pf);

        Intent dismiss = new Intent(this, AlarmService.class);
        dismiss.setAction(ACTION_DISMISS);
        PendingIntent dismissPi = PendingIntent.getService(this, 13, dismiss, pf);

        NotificationCompat.Builder b = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(curTitle)
                .setContentText(curBody.length() > 0 ? curBody : "Time for your reminder")
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setAutoCancel(false)
                .setContentIntent(fullPi)
                .setFullScreenIntent(fullPi, true)
                .addAction(0, "Snooze 5 min", snoozePi)
                .addAction(0, "Dismiss", dismissPi);
        return b.build();
    }

    private void startRinging() {
        stopRinging();

        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "TayyabReminder:alarm");
                wakeLock.acquire(MAX_RING_MS + 5000L);
            }
        } catch (Exception ignored) {
        }

        try {
            Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (uri == null) uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build());
            player.setDataSource(this, uri);
            player.setLooping(true);
            player.prepare();
            player.start();
        } catch (Exception e) {
            releasePlayer();
        }

        try {
            vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator != null) {
                long[] pattern = new long[]{0, 800, 600, 800, 600};
                if (Build.VERSION.SDK_INT >= 26) {
                    vibrator.vibrate(VibrationEffect.createWaveform(pattern, 0));
                } else {
                    vibrator.vibrate(pattern, 0);
                }
            }
        } catch (Exception ignored) {
        }
    }

    private void releasePlayer() {
        if (player != null) {
            try {
                if (player.isPlaying()) player.stop();
            } catch (Exception ignored) {
            }
            try {
                player.release();
            } catch (Exception ignored) {
            }
            player = null;
        }
    }

    private void stopRinging() {
        releasePlayer();
        if (vibrator != null) {
            try {
                vibrator.cancel();
            } catch (Exception ignored) {
            }
        }
        if (wakeLock != null) {
            try {
                if (wakeLock.isHeld()) wakeLock.release();
            } catch (Exception ignored) {
            }
            wakeLock = null;
        }
    }

    private void stopEverything() {
        handler.removeCallbacks(autoStop);
        stopRinging();
        try {
            if (Build.VERSION.SDK_INT >= 24) {
                stopForeground(Service.STOP_FOREGROUND_REMOVE);
            } else {
                stopForeground(true);
            }
        } catch (Exception ignored) {
        }
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(NOTIF_ID);

        Intent stopped = new Intent(ACTION_STOPPED);
        stopped.setPackage(getPackageName());
        sendBroadcast(stopped);

        stopSelf();
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(autoStop);
        stopRinging();
        super.onDestroy();
    }
}
