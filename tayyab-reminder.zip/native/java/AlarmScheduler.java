package com.tayyab.reminder;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Schedules exact alarms (AlarmManager.setAlarmClock) and remembers them
 * in SharedPreferences so they can be restored after a phone restart.
 */
public class AlarmScheduler {
    static final String PREFS = "tayyab_alarms";
    static final String KEY = "list";
    static final String ACTION_FIRE = "com.tayyab.reminder.ALARM_FIRE";

    static int flags() {
        int f = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) f |= PendingIntent.FLAG_IMMUTABLE;
        return f;
    }

    static int code(String id) {
        return id.hashCode() & 0x7fffffff;
    }

    static synchronized JSONArray load(Context c) {
        try {
            SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            return new JSONArray(sp.getString(KEY, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    static synchronized void store(Context c, JSONArray arr) {
        SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        sp.edit().putString(KEY, arr.toString()).apply();
    }

    private static PendingIntent firePi(Context c, String id, String title, String body, long time) {
        Intent i = new Intent(c, AlarmReceiver.class);
        i.setAction(ACTION_FIRE);
        i.putExtra("id", id);
        i.putExtra("title", title);
        i.putExtra("body", body);
        i.putExtra("time", time);
        return PendingIntent.getBroadcast(c, code(id), i, flags());
    }

    /** Set the OS alarm only (no persistence). */
    static void setOsAlarm(Context c, String id, String title, String body, long time) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        PendingIntent op = firePi(c, id, title, body, time);

        Intent open = new Intent(c, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent show = PendingIntent.getActivity(c, code(id), open, flags());

        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, op);
            } else {
                am.setAlarmClock(new AlarmManager.AlarmClockInfo(time, show), op);
            }
        } catch (SecurityException e) {
            am.set(AlarmManager.RTC_WAKEUP, time, op);
        }
    }

    static void cancelOsAlarm(Context c, String id) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        PendingIntent op = firePi(c, id, "", "", 0L);
        am.cancel(op);
        op.cancel();
    }

    /** Add (or replace) one alarm and persist it. */
    static void add(Context c, String id, String title, String body, long time) {
        try {
            JSONArray old = load(c);
            JSONArray out = new JSONArray();
            for (int i = 0; i < old.length(); i++) {
                JSONObject o = old.getJSONObject(i);
                if (!id.equals(o.optString("id"))) out.put(o);
            }
            JSONObject n = new JSONObject();
            n.put("id", id);
            n.put("title", title);
            n.put("body", body);
            n.put("time", time);
            out.put(n);
            store(c, out);
            setOsAlarm(c, id, title, body, time);
        } catch (Exception ignored) {
        }
    }

    /** Replace all task alarms with the given list. Snoozed alarms are kept. */
    static void syncAll(Context c, JSONArray fresh) {
        try {
            JSONArray old = load(c);
            JSONArray keep = new JSONArray();
            for (int i = 0; i < old.length(); i++) {
                JSONObject o = old.getJSONObject(i);
                String id = o.optString("id");
                if (id.startsWith("snooze:")) {
                    keep.put(o);
                } else {
                    cancelOsAlarm(c, id);
                }
            }
            long now = System.currentTimeMillis();
            for (int i = 0; i < fresh.length(); i++) {
                JSONObject o = fresh.getJSONObject(i);
                String id = o.getString("id");
                long time = o.getLong("time");
                if (time <= now) continue;
                String title = o.optString("title", "Reminder");
                String body = o.optString("body", "");
                setOsAlarm(c, id, title, body, time);
                keep.put(o);
            }
            store(c, keep);
        } catch (Exception ignored) {
        }
    }

    /** Remove an entry from storage after it fired. */
    static void removeEntry(Context c, String id) {
        try {
            JSONArray old = load(c);
            JSONArray out = new JSONArray();
            for (int i = 0; i < old.length(); i++) {
                JSONObject o = old.getJSONObject(i);
                if (!id.equals(o.optString("id"))) out.put(o);
            }
            store(c, out);
        } catch (Exception ignored) {
        }
    }

    /** After reboot / app update: set all future alarms again. */
    static void rescheduleAll(Context c) {
        try {
            JSONArray old = load(c);
            JSONArray out = new JSONArray();
            long now = System.currentTimeMillis();
            for (int i = 0; i < old.length(); i++) {
                JSONObject o = old.getJSONObject(i);
                long time = o.optLong("time", 0L);
                if (time > now) {
                    setOsAlarm(c, o.getString("id"), o.optString("title", "Reminder"), o.optString("body", ""), time);
                    out.put(o);
                }
            }
            store(c, out);
        } catch (Exception ignored) {
        }
    }
}
