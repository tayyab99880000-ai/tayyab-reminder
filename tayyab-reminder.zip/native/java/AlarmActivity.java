package com.tayyab.reminder;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Full-screen alarm screen shown over the lock screen. */
public class AlarmActivity extends Activity {
    private TextView timeView;
    private TextView titleView;
    private TextView bodyView;
    private String id = "alarm";
    private String title = "Reminder";
    private String body = "";
    private BroadcastReceiver stopReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(
                    WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                            | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        buildUi();
        render(getIntent());

        stopReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                finish();
            }
        };
        IntentFilter f = new IntentFilter(AlarmService.ACTION_STOPPED);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(stopReceiver, f, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(stopReceiver, f);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        render(intent);
    }

    private void render(Intent i) {
        if (i != null) {
            String a = i.getStringExtra("id");
            if (a != null) id = a;
            String t = i.getStringExtra("title");
            if (t != null) title = t;
            String b = i.getStringExtra("body");
            if (b != null) body = b;
        }
        long time = i != null ? i.getLongExtra("time", System.currentTimeMillis()) : System.currentTimeMillis();
        timeView.setText(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date(time)));
        titleView.setText(title);
        bodyView.setText(body.length() > 0 ? body : "Time for your reminder");
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Color.parseColor("#202A44"));
        root.setPadding(dp(28), dp(72), dp(28), dp(40));

        // Bell circle
        TextView bell = new TextView(this);
        bell.setText("\uD83D\uDD14");
        bell.setTextSize(TypedValue.COMPLEX_UNIT_SP, 44);
        bell.setGravity(Gravity.CENTER);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(Color.parseColor("#4A90E2"));
        bell.setBackground(circle);
        LinearLayout.LayoutParams bellLp = new LinearLayout.LayoutParams(dp(110), dp(110));
        bellLp.bottomMargin = dp(28);
        root.addView(bell, bellLp);

        TextView label = new TextView(this);
        label.setText("REMINDER");
        label.setTextColor(Color.parseColor("#8FB8EE"));
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        label.setLetterSpacing(0.2f);
        label.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(label);

        timeView = new TextView(this);
        timeView.setTextColor(Color.WHITE);
        timeView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 64);
        timeView.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(timeView);

        titleView = new TextView(this);
        titleView.setTextColor(Color.WHITE);
        titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
        titleView.setTypeface(Typeface.DEFAULT_BOLD);
        titleView.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tLp.topMargin = dp(16);
        root.addView(titleView, tLp);

        bodyView = new TextView(this);
        bodyView.setTextColor(Color.parseColor("#C9D3E6"));
        bodyView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        bodyView.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams bLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bLp.topMargin = dp(10);
        root.addView(bodyView, bLp);

        // Spacer
        View spacer = new View(this);
        root.addView(spacer, new LinearLayout.LayoutParams(1, 0, 1f));

        Button snooze = makeButton("Snooze 5 min", Color.parseColor("#324066"), Color.WHITE, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent s = new Intent(AlarmActivity.this, AlarmService.class);
                s.setAction(AlarmService.ACTION_SNOOZE);
                s.putExtra("id", id);
                s.putExtra("title", title);
                s.putExtra("body", body);
                startService(s);
                finish();
            }
        });
        root.addView(snooze);

        Button dismiss = makeButton("Dismiss", Color.parseColor("#4A90E2"), Color.WHITE, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent s = new Intent(AlarmActivity.this, AlarmService.class);
                s.setAction(AlarmService.ACTION_DISMISS);
                startService(s);
                finish();
            }
        });
        root.addView(dismiss);

        setContentView(root);
    }

    private Button makeButton(String text, int bg, int fg, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(fg);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(bg);
        gd.setCornerRadius(dp(28));
        b.setBackground(gd);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(56));
        lp.topMargin = dp(14);
        b.setLayoutParams(lp);
        b.setOnClickListener(l);
        return b;
    }

    @Override
    public void onBackPressed() {
        // Ignore back: user must choose Snooze or Dismiss.
    }

    @Override
    protected void onDestroy() {
        if (stopReceiver != null) {
            try {
                unregisterReceiver(stopReceiver);
            } catch (Exception ignored) {
            }
        }
        super.onDestroy();
    }
}
