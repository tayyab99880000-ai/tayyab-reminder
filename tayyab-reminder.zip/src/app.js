// ===== Tayyab Reminder - app logic =====
const STORAGE_KEY = 'tayyab_reminder_tasks';
const SEEN_KEY = 'tayyab_reminder_seen';
const NOTIFY_KEY = 'tayyab_reminder_notify_global';

let tasks = [];
let currentFilter = 'all';
let activeScreenId = 'screen-home';
let pendingDeleteId = null;

// Native bridge (only exists inside the Android app)
function native() {
  return (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.TayyabAlarm) || null;
}

// ---------- helpers ----------
function pad(n) { return String(n).padStart(2, '0'); }
function localDateStr(d) {
  d = d || new Date();
  return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
}
function esc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
function taskTimestamp(t) {
  const ts = new Date(t.date + 'T' + t.time + ':00').getTime();
  return isNaN(ts) ? 0 : ts;
}
function globalNotifyOn() {
  return localStorage.getItem(NOTIFY_KEY) !== '0';
}

// ---------- init ----------
window.addEventListener('load', function () {
  loadTasks();

  document.getElementById('task-date-input').value = localDateStr();
  document.getElementById('task-time-input').value = '12:00';

  const globalToggle = document.getElementById('global-notification-setting');
  globalToggle.checked = globalNotifyOn();
  globalToggle.addEventListener('change', function () {
    localStorage.setItem(NOTIFY_KEY, globalToggle.checked ? '1' : '0');
    syncAlarms();
    showToast('Notification Alerts', globalToggle.checked ? 'Alarms are ON' : 'Alarms are OFF');
  });

  renderAll();

  // Splash only on first launch
  if (localStorage.getItem(SEEN_KEY)) {
    document.getElementById('screen-splash').classList.add('hidden');
    showScreen('screen-home');
  }

  syncAlarms();
  refreshPermStatus();
  document.addEventListener('visibilitychange', function () {
    if (!document.hidden) refreshPermStatus();
  });
  setInterval(function () { renderDashboard(); }, 60000);
});

function startApp() {
  localStorage.setItem(SEEN_KEY, '1');
  const n = native();
  if (n) { n.requestNotifications().catch(function () {}); }
  document.getElementById('screen-splash').classList.add('hidden');
  showScreen('screen-home');
}

// ---------- storage ----------
function loadTasks() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    tasks = saved ? JSON.parse(saved) : [];
    if (!Array.isArray(tasks)) tasks = [];
  } catch (e) {
    tasks = [];
  }
}

function saveTasks() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
  renderAll();
  syncAlarms();
}

function clearAllTasks() {
  if (!confirm('Delete ALL tasks? This cannot be undone.')) return;
  tasks = [];
  saveTasks();
  showToast('Cleared', 'All tasks removed.');
}

// ---------- native alarm sync ----------
function syncAlarms() {
  const n = native();
  if (!n) return;
  const now = Date.now();
  const alarms = [];
  if (globalNotifyOn()) {
    tasks.forEach(function (t) {
      if (!t.notify || t.completed) return;
      const ts = taskTimestamp(t);
      if (ts > now) {
        alarms.push({
          id: String(t.id),
          title: t.title,
          body: t.description || 'Time for your reminder',
          timestamp: ts
        });
      }
    });
  }
  n.syncAll({ alarms: alarms }).catch(function (e) { console.log('syncAll error', e); });
}

function testAlarm() {
  const n = native();
  if (!n) { showToast('Test Alarm', 'Works only inside the Android app.'); return; }
  n.testAlarm().then(function () {
    showToast('Test Alarm set', 'Lock your phone. It rings in 10 seconds.');
  }).catch(function () {
    showToast('Error', 'Could not set test alarm.');
  });
}

// ---------- permission status ----------
function setPermButton(key, ok) {
  const b = document.getElementById('perm-' + key);
  if (!b) return;
  if (ok) {
    b.textContent = 'OK';
    b.className = 'shrink-0 ml-2 text-[10px] font-bold px-3 py-1.5 rounded-full bg-green-100 text-green-700';
  } else {
    b.textContent = 'Fix';
    b.className = 'shrink-0 ml-2 text-[10px] font-bold px-3 py-1.5 rounded-full bg-brand-blue text-white';
  }
}

function refreshPermStatus() {
  const n = native();
  const banner = document.getElementById('perm-banner');
  if (!n) { banner.classList.add('hidden'); return; }
  n.checkStatus().then(function (s) {
    setPermButton('notifications', s.notifications);
    setPermButton('exact', s.exact);
    setPermButton('fullscreen', s.fullScreen);
    setPermButton('battery', s.battery);
    // Auto-start cannot be detected; user confirms it once
    setPermButton('autostart', localStorage.getItem('tr_autostart_done') === '1');
    const critical = s.notifications && s.exact && s.fullScreen && s.battery;
    if (critical) banner.classList.add('hidden'); else banner.classList.remove('hidden');
  }).catch(function () {});
}

function fixPermission(key) {
  const n = native();
  if (!n) { showToast('Settings', 'Works only inside the Android app.'); return; }
  if (key === 'autostart') {
    localStorage.setItem('tr_autostart_done', '1');
    showToast('Auto-start', 'Turn ON "Tayyab Reminder" in the list.');
  }
  if (key === 'notifications') {
    n.requestNotifications().then(function () { setTimeout(refreshPermStatus, 800); }).catch(function () {});
    return;
  }
  n.openSetting({ type: key }).catch(function () {});
}

// ---------- navigation ----------
let extraEntry = false;
let suppressPop = false;

function pushEntry() {
  if (!extraEntry) { history.pushState({ a: 1 }, ''); extraEntry = true; }
}
function dropEntry() {
  if (extraEntry) { suppressPop = true; extraEntry = false; history.back(); }
}
function modalOpen() {
  return !document.getElementById('screen-edit').classList.contains('hidden') ||
         !document.getElementById('screen-delete').classList.contains('hidden');
}
function hideModals() {
  document.getElementById('screen-edit').classList.add('hidden');
  document.getElementById('screen-delete').classList.add('hidden');
  pendingDeleteId = null;
}

window.addEventListener('popstate', function () {
  if (suppressPop) { suppressPop = false; return; }
  extraEntry = false;
  if (modalOpen()) {
    hideModals();
    if (activeScreenId !== 'screen-home') pushEntry();
    return;
  }
  if (activeScreenId !== 'screen-home') showScreen('screen-home');
});

function showScreen(screenId) {
  ['screen-home', 'screen-add', 'screen-tasks', 'screen-settings'].forEach(function (id) {
    document.getElementById(id).classList.add('hidden');
  });
  document.getElementById(screenId).classList.remove('hidden');
  activeScreenId = screenId;
  updateBottomNav(screenId);
  const fab = document.getElementById('main-fab');
  if (screenId === 'screen-home' || screenId === 'screen-tasks') fab.classList.remove('hidden');
  else fab.classList.add('hidden');
  document.getElementById('app-viewport').scrollTop = 0;
  if (screenId === 'screen-settings' || screenId === 'screen-home') refreshPermStatus();
}

function navigateTo(screenId) {
  if (screenId === 'screen-splash') return;
  if (screenId === 'screen-home') {
    showScreen('screen-home');
    if (!modalOpen()) dropEntry();
  } else {
    showScreen(screenId);
    pushEntry();
  }
}

function updateBottomNav(screenId) {
  const map = { 'screen-home': 'nav-home', 'screen-tasks': 'nav-tasks', 'screen-settings': 'nav-settings' };
  ['nav-home', 'nav-tasks', 'nav-settings'].forEach(function (id) {
    document.getElementById(id).className = 'flex flex-col items-center space-y-1 text-slate-400 hover:text-brand-navy transition';
  });
  if (map[screenId]) {
    document.getElementById(map[screenId]).className = 'flex flex-col items-center space-y-1 text-brand-blue transition';
  }
}

// ---------- CRUD ----------
function handleAddTask(e) {
  e.preventDefault();
  const title = document.getElementById('task-title-input').value.trim();
  const desc = document.getElementById('task-desc-input').value.trim();
  const date = document.getElementById('task-date-input').value;
  const time = document.getElementById('task-time-input').value;
  const notify = document.getElementById('task-notify-toggle').checked;
  if (!title) return;

  const task = { id: Date.now().toString(), title: title, description: desc, date: date, time: time, completed: false, notify: notify };
  tasks.unshift(task);
  saveTasks();

  document.getElementById('add-task-form').reset();
  document.getElementById('task-date-input').value = localDateStr();
  document.getElementById('task-time-input').value = '12:00';

  if (notify && taskTimestamp(task) <= Date.now()) {
    showToast('Task saved', 'Time is in the past, so no alarm will ring.');
  } else {
    showToast('Task Created!', '"' + title + '" has been added.');
  }
  navigateTo('screen-tasks');
}

function toggleTaskComplete(id) {
  tasks = tasks.map(function (t) {
    if (t.id === id) {
      const updated = !t.completed;
      showToast(updated ? 'Task Completed! 🎉' : 'Task Marked Pending', t.title);
      return Object.assign({}, t, { completed: updated });
    }
    return t;
  });
  saveTasks();
}

function openEditModal(id) {
  const task = tasks.find(function (t) { return t.id === id; });
  if (!task) return;
  document.getElementById('edit-task-id').value = task.id;
  document.getElementById('edit-title').value = task.title;
  document.getElementById('edit-desc').value = task.description || '';
  document.getElementById('edit-date').value = task.date;
  document.getElementById('edit-time').value = task.time;
  document.getElementById('edit-notify').checked = !!task.notify;
  document.getElementById('screen-edit').classList.remove('hidden');
  pushEntry();
}

function closeEditModal() {
  document.getElementById('screen-edit').classList.add('hidden');
  if (activeScreenId === 'screen-home' && !modalOpen()) dropEntry();
}

function handleSaveEdit(e) {
  e.preventDefault();
  const id = document.getElementById('edit-task-id').value;
  const title = document.getElementById('edit-title').value.trim();
  const desc = document.getElementById('edit-desc').value.trim();
  const date = document.getElementById('edit-date').value;
  const time = document.getElementById('edit-time').value;
  const notify = document.getElementById('edit-notify').checked;

  tasks = tasks.map(function (t) {
    return t.id === id ? Object.assign({}, t, { title: title, description: desc, date: date, time: time, notify: notify }) : t;
  });
  saveTasks();
  closeEditModal();
  showToast('Task Updated', 'Changes saved successfully.');
}

function promptDeleteTask(id) {
  pendingDeleteId = id;
  document.getElementById('screen-delete').classList.remove('hidden');
  pushEntry();
}

function closeDeleteModal() {
  pendingDeleteId = null;
  document.getElementById('screen-delete').classList.add('hidden');
  if (activeScreenId === 'screen-home' && !modalOpen()) dropEntry();
}

function confirmDeleteTask() {
  if (!pendingDeleteId) return;
  tasks = tasks.filter(function (t) { return t.id !== pendingDeleteId; });
  saveTasks();
  closeDeleteModal();
  showToast('Task Deleted', 'Task removed.');
}

// ---------- filter & render ----------
function setFilter(filter) {
  currentFilter = filter;
  ['all', 'pending', 'completed'].forEach(function (f) {
    const btn = document.getElementById('filter-' + f);
    btn.className = f === filter
      ? 'flex-1 py-1.5 text-xs font-bold rounded-xl transition text-white bg-brand-blue shadow'
      : 'flex-1 py-1.5 text-xs font-medium text-slate-500 rounded-xl transition hover:text-brand-navy';
  });
  renderTaskList();
}

function renderAll() {
  renderDashboard();
  renderTaskList();
}

function renderDashboard() {
  const total = tasks.length;
  const completed = tasks.filter(function (t) { return t.completed; }).length;
  document.getElementById('stat-total').innerText = total;
  document.getElementById('stat-completed').innerText = completed;
  document.getElementById('stat-pending').innerText = total - completed;

  const now = new Date();
  document.getElementById('dashboard-date').innerText =
    'Today, ' + now.toLocaleDateString('en-GB', { day: 'numeric', month: 'long' });

  const todayStr = localDateStr(now);
  const todayTasks = tasks.filter(function (t) { return t.date === todayStr; })
    .sort(function (a, b) { return a.time.localeCompare(b.time); });

  const todayContainer = document.getElementById('home-today-list');
  if (todayTasks.length === 0) {
    todayContainer.innerHTML = '<p class="text-xs text-slate-400 italic py-2">No tasks scheduled for today.</p>';
  } else {
    todayContainer.innerHTML = todayTasks.map(function (t) {
      return '' +
        '<div class="bg-brand-bgLight p-3 rounded-2xl border border-slate-200/80 flex items-center justify-between">' +
          '<div class="flex items-center space-x-3 min-w-0">' +
            '<button onclick="toggleTaskComplete(\'' + t.id + '\')" class="w-5 h-5 rounded-md border ' + (t.completed ? 'bg-brand-success border-brand-success text-white' : 'border-slate-300 bg-white') + ' flex items-center justify-center transition">' +
              (t.completed ? '<i class="ph-bold ph-check text-xs"></i>' : '') +
            '</button>' +
            '<div class="min-w-0">' +
              '<p class="text-xs font-bold ' + (t.completed ? 'line-through text-slate-400' : 'text-brand-navy') + ' truncate">' + esc(t.title) + '</p>' +
              '<p class="text-[10px] text-slate-500">' + esc(t.time) + ' • ' + (t.notify ? '🔔 Alert set' : 'No alert') + '</p>' +
            '</div>' +
          '</div>' +
          '<button onclick="openEditModal(\'' + t.id + '\')" class="text-slate-400 hover:text-brand-blue p-1">' +
            '<i class="ph-bold ph-pencil text-xs"></i>' +
          '</button>' +
        '</div>';
    }).join('');
  }

  const upcoming = tasks.filter(function (t) { return t.date > todayStr; })
    .sort(function (a, b) { return (a.date + a.time).localeCompare(b.date + b.time); });
  const upcomingContainer = document.getElementById('home-upcoming-list');
  if (upcoming.length === 0) {
    upcomingContainer.innerHTML = '<p class="text-xs text-slate-400 italic py-2">No upcoming tasks.</p>';
  } else {
    upcomingContainer.innerHTML = upcoming.slice(0, 3).map(function (t) {
      return '' +
        '<div class="bg-brand-bgLight p-3 rounded-2xl border border-slate-200/80 flex items-center justify-between">' +
          '<div>' +
            '<p class="text-xs font-bold text-brand-navy">' + esc(t.title) + '</p>' +
            '<p class="text-[10px] text-slate-500">' + esc(t.date) + ' at ' + esc(t.time) + '</p>' +
          '</div>' +
          '<span class="text-[9px] bg-slate-200 text-slate-600 font-bold px-2 py-0.5 rounded-full">Upcoming</span>' +
        '</div>';
    }).join('');
  }
}

function renderTaskList() {
  let filtered = tasks;
  if (currentFilter === 'pending') filtered = tasks.filter(function (t) { return !t.completed; });
  if (currentFilter === 'completed') filtered = tasks.filter(function (t) { return t.completed; });

  document.getElementById('task-count-badge').innerText = filtered.length + ' Tasks';

  const container = document.getElementById('full-task-list');
  if (filtered.length === 0) {
    container.innerHTML = '' +
      '<div class="text-center py-10 space-y-2">' +
        '<div class="w-12 h-12 rounded-full bg-slate-100 text-slate-400 mx-auto flex items-center justify-center">' +
          '<i class="ph-bold ph-tray text-xl"></i>' +
        '</div>' +
        '<p class="text-xs text-slate-400 font-medium">No tasks found in this section.</p>' +
      '</div>';
    return;
  }

  container.innerHTML = filtered.map(function (t) {
    return '' +
      '<div class="bg-brand-bgLight p-3.5 rounded-2xl border border-slate-200/80 space-y-2 hover:border-brand-blue/40 transition">' +
        '<div class="flex items-start justify-between">' +
          '<div class="flex items-start space-x-3 min-w-0">' +
            '<button onclick="toggleTaskComplete(\'' + t.id + '\')" class="mt-0.5 w-5 h-5 rounded-md border ' + (t.completed ? 'bg-brand-success border-brand-success text-white' : 'border-slate-300 bg-white') + ' flex items-center justify-center transition">' +
              (t.completed ? '<i class="ph-bold ph-check text-xs"></i>' : '') +
            '</button>' +
            '<div class="min-w-0">' +
              '<h4 class="text-xs font-bold ' + (t.completed ? 'line-through text-slate-400' : 'text-brand-navy') + '">' + esc(t.title) + '</h4>' +
              (t.description ? '<p class="text-[11px] text-slate-500 mt-0.5 line-clamp-2">' + esc(t.description) + '</p>' : '') +
            '</div>' +
          '</div>' +
          '<div class="flex items-center space-x-1 ml-2">' +
            '<button onclick="openEditModal(\'' + t.id + '\')" class="p-1.5 text-slate-400 hover:text-brand-blue rounded-lg hover:bg-white transition">' +
              '<i class="ph-bold ph-pencil text-xs"></i>' +
            '</button>' +
            '<button onclick="promptDeleteTask(\'' + t.id + '\')" class="p-1.5 text-slate-400 hover:text-brand-danger rounded-lg hover:bg-white transition">' +
              '<i class="ph-bold ph-trash text-xs"></i>' +
            '</button>' +
          '</div>' +
        '</div>' +
        '<div class="flex items-center justify-between pt-2 border-t border-slate-200/60 text-[10px] text-slate-500">' +
          '<div class="flex items-center space-x-2">' +
            '<span class="flex items-center space-x-1"><i class="ph-bold ph-calendar"></i><span>' + esc(t.date) + '</span></span>' +
            '<span class="flex items-center space-x-1"><i class="ph-bold ph-clock"></i><span>' + esc(t.time) + '</span></span>' +
          '</div>' +
          (t.notify ? '<span class="text-brand-blue flex items-center space-x-0.5"><i class="ph-bold ph-bell"></i><span>Alert</span></span>' : '') +
        '</div>' +
      '</div>';
  }).join('');
}

// ---------- toast ----------
let toastTimer = null;
function showToast(title, msg) {
  const toast = document.getElementById('toast-banner');
  document.getElementById('toast-title').innerText = title;
  document.getElementById('toast-msg').innerText = msg;
  toast.classList.remove('translate-y-[-100px]', 'opacity-0');
  toast.classList.add('translate-y-0', 'opacity-100');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(function () {
    toast.classList.remove('translate-y-0', 'opacity-100');
    toast.classList.add('translate-y-[-100px]', 'opacity-0');
  }, 2800);
}
